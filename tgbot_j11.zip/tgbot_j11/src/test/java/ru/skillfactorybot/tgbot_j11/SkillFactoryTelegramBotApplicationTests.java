package ru.skillfactorybot.tgbot_j11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillFactoryTelegramBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
